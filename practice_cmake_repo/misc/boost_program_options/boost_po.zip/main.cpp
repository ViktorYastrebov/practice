
#if 0
// Copyright Vladimir Prus 2002-2004.
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)


#include <boost/program_options.hpp>
using namespace boost::program_options;

#include <iostream>
using namespace std;

// Auxiliary functions for checking input for validity.

// Function used to check that 'opt1' and 'opt2' are not specified
//at the same time.
void conflicting_options(const variables_map& vm,
  const char* opt1, const char* opt2)
{
  if (vm.count(opt1) && !vm[opt1].defaulted()
    && vm.count(opt2) && !vm[opt2].defaulted())
    throw logic_error(string("Conflicting options '")
      + opt1 + "' and '" + opt2 + "'.");
}

// Function used to check that of 'for_what' is specified, then
//'required_option' is specified too.
void option_dependency(const variables_map& vm,
  const char* for_what, const char* required_option)
{
  if (vm.count(for_what) && !vm[for_what].defaulted())
    if (vm.count(required_option) == 0 || vm[required_option].defaulted())
      throw logic_error(string("Option '") + for_what
        + "' requires option '" + required_option + "'.");
}

int main(int argc, char* argv[])
{
  try {
    string ofile;
    string macrofile, libmakfile;
    bool t_given = false;
    bool b_given = false;
    string mainpackage;
    string depends = "deps_file";
    string sources = "src_file";
    string root = ".";

    options_description desc("Allowed options");
    desc.add_options()
      // First parameter describes option name/short name
      // The second is parameter to option
      // The third is description
      ("help,h", "print usage message")
      ("output,o", value(&ofile), "pathname for output")
      ("macrofile,m", value(&macrofile), "full pathname of macro.h")
      ("two,t", bool_switch(&t_given), "preprocess both header and body")
      ("body,b", bool_switch(&b_given), "preprocess body in the header context")
      ("libmakfile,l", value(&libmakfile),
        "write include makefile for library")
        ("mainpackage,p", value(&mainpackage),
          "output dependency information")
          ("depends,d", value(&depends),
            "write dependencies to <pathname>")
            ("sources,s", value(&sources), "write source package list to <pathname>")
      ("root,r", value(&root), "treat <dirname> as project root directory")
      ;

    variables_map vm;
    store(parse_command_line(argc, argv, desc), vm);

    cout << desc << std::endl;

    if (vm.count("help")) {
      cout << desc << "\n";
      return 0;
    }

    conflicting_options(vm, "output", "two");
    conflicting_options(vm, "output", "body");
    conflicting_options(vm, "output", "mainpackage");
    conflicting_options(vm, "two", "mainpackage");
    conflicting_options(vm, "body", "mainpackage");

    conflicting_options(vm, "two", "body");
    conflicting_options(vm, "libmakfile", "mainpackage");
    conflicting_options(vm, "libmakfile", "mainpackage");

    option_dependency(vm, "depends", "mainpackage");
    option_dependency(vm, "sources", "mainpackage");
    option_dependency(vm, "root", "mainpackage");

    cout << "two = " << vm["two"].as<bool>() << "\n";
  }
  catch (exception& e) {
    cerr << e.what() << "\n";
  }
}


#else
#include <iostream>
#include <boost/program_options.hpp>
#include <string>

namespace po = boost::program_options;

auto main(int argc, char *argv[]) -> int {
  std::string value1;
  std::string value2;
  std::string value3;
  bool isValue;

  po::options_description desc("Options");
  //po::options_description internal_desc("Hidden command line options");
  //po::options_description combined_options;
  desc.add_options()
    ("help,h", "Show help")
    ("value1,x", po::value(&value1), "Set value1")
    ("value2,y", po::value<std::string>(&value2), "Set value2")
    ("value3,z", po::value<std::string>(&value3), "Set value3")
    ("isValue,y", po::bool_switch(&isValue), "Set isValue")
    //("v", po::value<bool>()->zero_tokens(), "Show version")
    ;

  //internal_desc.add_options()
  //  ("form-file", po::value<std::string>(&inputFile))
  //  ;
  //combined_options.add(desc).add(internal_desc);

  //po::positional_options_description p;
  //p.add("form-file", 1);

  po::variables_map vm;
  store(parse_command_line(argc, argv, desc), vm);

  //DO NOT USE MOTIFY HERE.
#if 0
  try {
    po::store(cp.style(boost::program_options::command_line_style::default_style |
      boost::program_options::command_line_style::allow_long_disguise |
      boost::program_options::command_line_style::case_insensitive).allow_unregistered().run(), vm);
    po::notify(vm);
  } catch (std::exception &e) {
    std::cout << e.what() << std::endl;
  }
#endif

  try {
    if (vm.count("help")) {
      std::cout << desc << std::endl;
      return 0;
    }
    if (vm.count("value1")) {
      value1 = vm["value1"].as<std::string>();
    }
    if (vm.count("value2")) {
      value2 = vm["value2"].as<std::string>();
    }
    if (vm.count("value3")) {
      value3 = vm["value3"].as<std::string>();
    }

    std::cout << "value 1 : " << value1 << std::endl;
    std::cout << "value 2 : " << value2 << std::endl;
    std::cout << "value 3 : " << value3 << std::endl;
    std::cout << "isValue : " << std::boolalpha << isValue << std::endl;

  } catch (std::exception &e) {
    std::cout << e.what() << std::endl;
  }

  return 0;
}
#endif